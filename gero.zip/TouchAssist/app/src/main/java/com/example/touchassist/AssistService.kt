package com.example.touchassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class AssistService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistService? = null

        /** الإيماءة اللي لسه متسجلة ومستنية الاسم في شاشة الحفظ */
        @Volatile
        var pending: Gesture? = null
    }

    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val handler = Handler(Looper.getMainLooper())
    private val fadeHandler = Handler(Looper.getMainLooper())

    private var button: AssistButton? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var recorder: View? = null
    private var placer: View? = null
    private val pageStack = ArrayList<String>()

    private var playing = false
    private var runToken = 0
    private var dragStartX = 0
    private var dragStartY = 0

    // الدواير الثابتة (Armed)
    private var armedGesture: Gesture? = null
    private var armedView: View? = null
    private var armedLp: WindowManager.LayoutParams? = null
    private var armedBaseX = 0
    private var armedBaseY = 0
    private var onEnd: (() -> Unit)? = null

    private class MI(val icon: String, val label: String, val action: String)
    private class Spec(val start: Long, val dur: Long, val path: Path)
    private class Chunk(val specs: List<Spec>, val minStart: Long, val endTime: Long)
    private class Seg(val path: Path, val dur: Long)

    // ───────────── دورة حياة الخدمة ─────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        refreshButton()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeOverlays()
        handler.post { clampButton() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        super.onDestroy()
    }

    private fun cleanup() {
        stopPlaying()
        closeOverlays()
        removeButton()
    }

    // ───────────── أدوات مساعدة ─────────────

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun rounded(color: String, radiusDp: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(Color.parseColor(color))
        d.cornerRadius = dp(radiusDp).toFloat()
        return d
    }

    private fun fullScreenParams(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    // ───────────── الزر العائم ─────────────

    fun refreshButton() {
        removeButton()
        if (Store.buttonEnabled(this)) addButton()
    }

    /** الزر يرجع واضح 100% ولما تسيبه ~4 ثواني يبهت لشفافية "Idle Opacity" زي iOS. */
    private fun wakeButton() {
        fadeHandler.removeCallbacksAndMessages(null)
        button?.animate()?.cancel()
        button?.alpha = 1f
        fadeHandler.postDelayed({
            button?.animate()?.alpha(Store.idleOpacity(this) / 100f)?.setDuration(400)?.start()
        }, 4000)
    }

    private fun addButton() {
        val size = dp(Store.btnSize(this))
        val v = AssistButton(this)
        v.hasDouble = Store.getAction(this, "double") != "none"
        v.longPressMs = Store.longPressMs(this).toLong()
        v.doubleTapMs = Store.doubleTapMs(this).toLong()

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val (sw, sh) = screenSize()
        val px = Store.posX(this)
        val py = Store.posY(this)
        lp.x = (if (px < 0) sw - size else px).coerceIn(0, max(0, sw - size))
        lp.y = (if (py < 0) sh / 2 else py).coerceIn(0, max(0, sh - size))

        v.listener = object : AssistButton.Listener {
            override fun onSingle() = trigger("single")
            override fun onDouble() = trigger("double")
            override fun onLong() = trigger("long")
            override fun onPress() {
                dragStartX = lp.x
                dragStartY = lp.y
                wakeButton()
            }

            override fun onDrag(dx: Float, dy: Float) {
                val (w, h) = screenSize()
                lp.x = (dragStartX + dx).toInt().coerceIn(0, max(0, w - lp.width))
                lp.y = (dragStartY + dy).toInt().coerceIn(0, max(0, h - lp.height))
                try {
                    wm.updateViewLayout(v, lp)
                } catch (_: Exception) {
                }
            }

            override fun onDragEnd() {
                val (w, _) = screenSize()
                lp.x = if (lp.x + lp.width / 2 < w / 2) 0 else w - lp.width
                try {
                    wm.updateViewLayout(v, lp)
                } catch (_: Exception) {
                }
                Store.setPos(this@AssistService, lp.x, lp.y)
                wakeButton()
            }
        }
        try {
            wm.addView(v, lp)
            button = v
            buttonLp = lp
            wakeButton()
        } catch (_: Exception) {
        }
    }

    private fun removeButton() {
        fadeHandler.removeCallbacksAndMessages(null)
        button?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        button = null
        buttonLp = null
    }

    private fun clampButton() {
        val v = button ?: return
        val lp = buttonLp ?: return
        val (sw, sh) = screenSize()
        lp.x = if (lp.x + lp.width / 2 < sw / 2) 0 else sw - lp.width
        lp.y = lp.y.coerceIn(0, max(0, sh - lp.height))
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    // ───────────── تنفيذ الإجراءات ─────────────

    private fun trigger(name: String) {
        if (playing) {
            stopPlaying()
            toast("اتوقّف التنفيذ")
            return
        }
        if (armedGesture != null) {
            // الدواير الثابتة ظاهرة: ضغطة مطوّلة = نفّذ الإيماءة، ضغطة واحدة = اخفي الدواير
            if (name == "long") {
                fireArmed()
                return
            }
            if (name == "single") {
                closeArmed()
                return
            }
        }
        perform(Store.getAction(this, name))
    }

    /** إجراء جاي من الزر نفسه (ضغطة/ضغطتين/مطوّلة). */
    private fun perform(id: String) {
        when {
            id == "none" -> {}
            id == "menu" -> showMenu("top", true)
            id == "device" || id == "more" || id == "rotate" || id == "custom" || id == "gestures" -> showMenu(id, true)
            id.startsWith("g:") -> runSavedGesture(id.substring(2))
            else -> exec(id)
        }
    }

    /**
     * إيماءة مربوطة بضغطة / ضغطتين / ضغطة مطوّلة على الزر: بتتنفّذ في مكان الكورة اللي ثبّتّها (من غير ما تفتح القايمة).
     * لو لسه ما حدّدتش مكان، بتظهر الكورة عشان تحطها.
     */
    private fun runSavedGesture(gid: String) {
        val g = Store.loadGestures(this).firstOrNull { it.id == gid }
        if (g == null) {
            toast("الإيماءة دي اتمسحت")
            return
        }
        if (!g.armed) {
            startGesture(g)
            return
        }
        if (armedGesture?.id == g.id) {
            fireArmed()
            return
        }
        val pin = Store.getPin(this, g.id)
        if (pin == null) {
            armGesture(g)
            return
        }
        runGesture(g, pin.first, pin.second, true)
    }

    private fun exec(id: String) {
        when {
            id == "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            id == "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            id == "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            id == "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            id == "control" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            id == "restart" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            id == "multitask" -> performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            id == "lock" -> {
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                else toast("قفل الشاشة بيحتاج أندرويد 9 أو أحدث")
            }
            id == "screenshot" -> {
                if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                else toast("لقطة الشاشة بتحتاج أندرويد 9 أو أحدث")
            }
            id == "vol_up" -> audio(AudioManager.ADJUST_RAISE)
            id == "vol_down" -> audio(AudioManager.ADJUST_LOWER)
            id == "mute" -> audio(AudioManager.ADJUST_TOGGLE_MUTE)
            id == "siri" -> voiceAssistant()
            id.startsWith("scroll_") -> scrollAction(id.substring(7))
            id == "camera" -> openCamera()
            id == "move_menu" -> moveMenuButton()
            id == "access_shortcut" -> openAccessibilitySettings()
            id.startsWith("rot_") -> setRotation(id.substring(4).toIntOrNull() ?: 0)
            id == "lock_rotation" -> toggleRotationLock()
            id.startsWith("p:") || id.startsWith("swipe:") -> {
                val (sw, sh) = screenSize()
                val g = Presets.build(id, sw, sh)
                if (g != null) showPlacer(g)
            }
            id.startsWith("g:") -> {
                val g = Store.loadGestures(this).firstOrNull { it.id == id.substring(2) }
                if (g != null) startGesture(g) else toast("الإيماءة دي اتمسحت")
            }
        }
    }

    private fun scrollAction(kind: String) {
        val (sw, sh) = screenSize()
        val cx = sw / 2f
        val cy = sh / 2f
        val dy = sh * 0.28f
        val dx = sw * 0.28f
        var x1 = cx
        var y1 = cy
        var x2 = cx
        var y2 = cy
        var rep = 1
        var delay = 0L
        var dur = 320L
        when (kind) {
            "up" -> { y1 = cy + dy; y2 = cy - dy }
            "down" -> { y1 = cy - dy; y2 = cy + dy }
            "left" -> { x1 = cx + dx; x2 = cx - dx }
            "right" -> { x1 = cx - dx; x2 = cx + dx }
            "top" -> { y1 = cy - dy; y2 = cy + dy; rep = 6; delay = 60L; dur = 180L }
            "bottom" -> { y1 = cy + dy; y2 = cy - dy; rep = 6; delay = 60L; dur = 180L }
            "h" -> { x1 = cx + dx; x2 = cx - dx; rep = 0; delay = 150L }
            "v" -> { y1 = cy + dy; y2 = cy - dy; rep = 0; delay = 150L }
            else -> return
        }
        val g = Gesture(
            "scroll", "scroll",
            listOf(Stroke(0L, listOf(Pt(x1, y1, 0L), Pt(x2, y2, dur)))),
            sw, sh, repeat = rep, repeatDelay = delay
        )
        runGesture(g, 0f, 0f, true)
    }

    private fun openCamera() {
        try {
            val i = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            toast("مفيش تطبيق كاميرا")
        }
    }

    private fun openAccessibilitySettings() {
        try {
            val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    /** "نقل القائمة": بيقلب الزر للحافة التانية ومكان تاني عشان ما يغطيش اللي تحته. */
    private fun moveMenuButton() {
        val v = button ?: return
        val lp = buttonLp ?: return
        val (sw, sh) = screenSize()
        lp.x = if (lp.x + lp.width / 2 < sw / 2) sw - lp.width else 0
        lp.y = (sh - lp.y - lp.height).coerceIn(0, max(0, sh - lp.height))
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
        Store.setPos(this, lp.x, lp.y)
        wakeButton()
    }

    private fun audio(dir: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustVolume(dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun voiceAssistant() {
        try {
            val i = Intent(Intent.ACTION_VOICE_COMMAND)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: ActivityNotFoundException) {
            try {
                val i = Intent(Intent.ACTION_ASSIST)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (_: Exception) {
                toast("مفيش مساعد صوتي متسجّل على الجهاز")
            }
        }
    }

    private fun needWriteSettings(): Boolean {
        if (Settings.System.canWrite(this)) return false
        toast("اسمح للتطبيق بتعديل إعدادات النظام الأول")
        try {
            val i = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
        }
        return true
    }

    private fun setRotation(r: Int) {
        if (needWriteSettings()) return
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.USER_ROTATION, r)
        } catch (_: Exception) {
            toast("ما قدرتش أغيّر اتجاه الشاشة")
        }
    }

    private fun toggleRotationLock() {
        if (needWriteSettings()) return
        try {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
            toast(if (cur == 1) "التدوير مقفول" else "التدوير شغّال")
        } catch (_: Exception) {
        }
    }

    private fun startGesture(g: Gesture) {
        when {
            g.armed -> armGesture(g)
            g.placeMode -> showPlacer(g)
            else -> runGesture(g, 0f, 0f)
        }
    }

    // ───────────── القائمة (زي قائمة AssistiveTouch) ─────────────

    private fun pageItems(page: String): List<MI> {
        fun mi(id: String) = MI(id, Actions.label(this, id), id)
        return when {
            page == "top" -> Store.topMenu(this).filter { it != "none" }.map { mi(it) }
            page == "device" -> listOf("lock", "rotate", "vol_up", "vol_down", "mute", "more").map { mi(it) }
            page == "more" -> listOf("screenshot", "recents", "restart", "multitask", "gestures", "lock_rotation", "back").map { mi(it) }
            page == "rotate" -> listOf("rot_0", "rot_1", "rot_3", "rot_2", "lock_rotation").map { mi(it) }
            page == "gestures" -> (1..5).map { mi("fingers:$it") }
            page.startsWith("fingers:") -> {
                val n = page.substring(8)
                listOf("up", "down", "left", "right").map { mi("swipe:$n:$it") }
            }
            page == "custom" -> {
                val l = ArrayList<MI>()
                for (g in Store.loadGestures(this)) l.add(mi("g:${g.id}"))
                for (id in listOf("p:pinch", "p:pinch_out", "p:pinch_rotate", "p:double_tap", "p:long_press")) l.add(mi(id))
                l.add(mi("newgesture"))
                l
            }
            else -> emptyList()
        }
    }

    private fun showMenu(page: String, reset: Boolean = false) {
        val first = menu == null
        if (reset) pageStack.clear()
        if (pageStack.lastOrNull() != page) pageStack.add(page)
        renderMenu(first)
    }

    private fun menuBack() {
        if (pageStack.isNotEmpty()) pageStack.removeAt(pageStack.size - 1)
        if (pageStack.isEmpty()) closeMenu() else renderMenu(false)
    }

    private fun onMenuItem(id: String) {
        when {
            id == "device" || id == "more" || id == "rotate" || id == "custom" ||
                id == "gestures" || id.startsWith("fingers:") -> showMenu(id)
            id == "newgesture" -> closeThen { startRecording() }
            else -> closeThen { exec(id) }
        }
    }

    private fun closeThen(action: () -> Unit) {
        closeMenu()
        handler.postDelayed({ action() }, 280)
    }

    /** ترتيب الأيقونات في شبكة 3×3 (المركز = رقم 4). */
    private fun slotsFor(count: Int, hasBack: Boolean): IntArray {
        if (hasBack) return intArrayOf(0, 1, 2, 3, 5, 6, 7, 8).copyOf(min(count, 8))
        return when (count) {
            1 -> intArrayOf(4)
            2 -> intArrayOf(3, 5)
            3 -> intArrayOf(0, 2, 7)
            4 -> intArrayOf(1, 3, 5, 7)
            5 -> intArrayOf(0, 2, 4, 6, 8)
            6 -> intArrayOf(0, 2, 3, 5, 6, 8)
            7 -> intArrayOf(0, 1, 2, 3, 5, 6, 7)
            else -> intArrayOf(0, 1, 2, 3, 5, 6, 7, 8)
        }
    }

    private fun makeCell(icon: String, label: String, onClick: () -> Unit): View {
        val cell = dp(80)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.layoutParams = LinearLayout.LayoutParams(cell, cell)
        c.addView(IconView(this, icon), LinearLayout.LayoutParams(dp(40), dp(40)))
        if (label.isNotEmpty()) {
            val t = TextView(this)
            t.text = label
            t.textSize = 10.5f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(dp(2), dp(2), dp(2), 0)
            c.addView(t, LinearLayout.LayoutParams(cell, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        c.setOnClickListener { onClick() }
        return c
    }

    private fun ringCell(m: MI?): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.addView(IconView(this, if (m == null) "chev" else m.icon), LinearLayout.LayoutParams(dp(38), dp(38)))
        if (m != null && m.label.isNotEmpty()) {
            val t = TextView(this)
            t.text = m.label
            t.textSize = 11f
            t.setTextColor(Color.WHITE)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(0, dp(2), 0, 0)
            c.addView(t, LinearLayout.LayoutParams(dp(82), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        c.setOnClickListener {
            if (m == null) menuBack() else onMenuItem(m.action)
        }
        return c
    }

    private fun renderMenu(animate: Boolean) {
        closeMenuView()
        val page = pageStack.lastOrNull() ?: return
        val items = pageItems(page)
        val hasBack = page != "top"
        val (sw, sh) = screenSize()

        val panel: ViewGroup
        val panelLp: FrameLayout.LayoutParams
        if (items.size <= 8) {
            val size = dp(270)
            val fp = FrameLayout(this)
            fp.background = rounded("#EE2B2B2D", 34)
            fp.isClickable = true
            val half = size / 2f
            val n = if (hasBack) max(items.size, 2) else items.size
            val offs = MenuGeometry.offsets(n, dp(88).toFloat(), dp(84).toFloat())
            val cw = dp(82)
            val ch = dp(74)
            for (i in items.indices) {
                val cell = ringCell(items[i])
                val lp = FrameLayout.LayoutParams(cw, ch)
                lp.gravity = Gravity.TOP or Gravity.START
                lp.leftMargin = (half + offs[i].x - cw / 2f).toInt()
                lp.topMargin = (half + offs[i].y - ch / 2f).toInt()
                fp.addView(cell, lp)
            }
            if (hasBack) {
                val lp = FrameLayout.LayoutParams(dp(56), dp(56))
                lp.gravity = Gravity.CENTER
                fp.addView(ringCell(null), lp)
            }
            panel = fp
            panelLp = FrameLayout.LayoutParams(size, size, Gravity.CENTER)
        } else {
            val cell = dp(80)
            val all = ArrayList<View>()
            if (hasBack) all.add(makeCell("chev", "") { menuBack() })
            for (m in items) all.add(makeCell(m.icon, m.label) { onMenuItem(m.action) })
            val grid = LinearLayout(this)
            grid.orientation = LinearLayout.VERTICAL
            var i = 0
            while (i < all.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in i until min(i + 3, all.size)) row.addView(all[k])
                grid.addView(row)
                i += 3
            }
            val rows = (all.size + 2) / 3
            val scroll = ScrollView(this)
            scroll.addView(grid)
            val lp2 = LinearLayout(this)
            lp2.orientation = LinearLayout.VERTICAL
            lp2.background = rounded("#EE2B2B2D", 26)
            lp2.setPadding(dp(8), dp(8), dp(8), dp(8))
            lp2.isClickable = true
            lp2.addView(
                scroll,
                LinearLayout.LayoutParams(cell * 3, min(cell * rows, (sh * 0.75f).toInt()))
            )
            panel = lp2
            panelLp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        }

        val root = FrameLayout(this)
        root.setOnClickListener { closeMenu() }
        root.addView(panel, panelLp)

        try {
            wm.addView(root, fullScreenParams())
            menu = root
            button?.visibility = View.INVISIBLE
        } catch (_: Exception) {
            return
        }

        if (animate) {
            panel.alpha = 0f
            panel.scaleX = 0.3f
            panel.scaleY = 0.3f
            panel.post {
                val bl = buttonLp
                val bx = if (bl != null) bl.x + bl.width / 2f else sw / 2f
                val by = if (bl != null) bl.y + bl.height / 2f else sh / 2f
                panel.pivotX = panel.width / 2f + (bx - sw / 2f)
                panel.pivotY = panel.height / 2f + (by - sh / 2f)
                panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            }
        }
    }

    private fun closeMenuView() {
        menu?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        menu = null
    }

    private fun closeMenu() {
        closeMenuView()
        pageStack.clear()
        button?.visibility = View.VISIBLE
        wakeButton()
    }

    // ───────────── تسجيل إيماءة جديدة ─────────────

    fun startRecording() {
        closeOverlays()
        val (sw, sh) = screenSize()
        val v = RecorderView(
            this, sw, sh,
            onSave = { g ->
                handler.post {
                    closeRecorder()
                    pending = g
                    openEditor(null)
                }
            },
            onCancel = { handler.post { closeRecorder() } }
        )
        try {
            wm.addView(v, fullScreenParams())
            recorder = v
        } catch (_: Exception) {
        }
    }

    private fun closeRecorder() {
        recorder?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        recorder = null
    }

    private fun openEditor(id: String?) {
        val i = Intent(this, GestureEditActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (id != null) i.putExtra("id", id)
        startActivity(i)
    }

    // ───────────── اختيار المكان (دواير زرقا زي iOS) ─────────────

    private fun showPlacer(g: Gesture) {
        closeOverlays()
        val (sw, sh) = screenSize()
        val v = PlaceView(
            this, g, sw, sh,
            onDone = { dx, dy ->
                handler.post {
                    closePlacer()
                    handler.postDelayed({ runGesture(g, dx, dy, true) }, 120)
                }
            },
            onCancel = { handler.post { closePlacer() } }
        )
        try {
            wm.addView(v, fullScreenParams())
            placer = v
        } catch (_: Exception) {
        }
    }

    private fun closePlacer() {
        placer?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        placer = null
    }

    private fun closeOverlays() {
        closeMenu()
        closeRecorder()
        closePlacer()
        closeArmed()
    }

    // ───────────── تشغيل الإيماءة / الماكرو ─────────────

    fun stopPlaying() {
        runToken++
        playing = false
        handler.removeCallbacksAndMessages(null)
        val e = onEnd
        onEnd = null
        e?.invoke()
    }

    // ───────────── الدواير الثابتة (Armed) ─────────────

    /** نقطة الارتكاز: بداية أول لمسة في الإيماءة. الكورة بتتحط عليها. */
    private fun anchorOf(g: Gesture): PointF? {
        val st = g.strokes.minByOrNull { it.startOffset } ?: return null
        val p = st.points.firstOrNull() ?: return null
        return PointF(p.x, p.y)
    }

    /** بتظهر كور (كورة لكل لمسة مسجّلة) عشان تحرّكها. لما تسيبها بتتحوّل لكورة واحدة ثابتة. */
    private fun armGesture(g: Gesture) {
        val a = anchorOf(g) ?: return
        val (sw, sh) = screenSize()
        val saved = Store.getPin(this, g.id)
        val tx = saved?.first ?: (sw / 2f - a.x)
        val ty = saved?.second ?: (sh / 2f - a.y)
        showBalls(g, tx, ty, true)
    }

    private fun showBalls(g: Gesture, tx0: Float, ty0: Float, multi: Boolean) {
        closeArmed()
        val a = anchorOf(g) ?: return
        val (sw, sh) = screenSize()
        val pts = ArrayList<PointF>()
        if (multi) {
            for (st in g.strokes) {
                val p = st.points.firstOrNull() ?: continue
                pts.add(PointF(p.x, p.y))
            }
        } else {
            pts.add(PointF(a.x, a.y))
        }
        if (pts.isEmpty()) return

        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (p in pts) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
        }
        val pad = dp(44)
        val baseX = (minX - pad).toInt()
        val baseY = (minY - pad).toInt()
        val w = (maxX - minX).toInt() + 2 * pad
        val h = (maxY - minY).toInt() + 2 * pad

        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (baseX + tx0).toInt().coerceIn(0, max(0, sw - w))
        lp.y = (baseY + ty0).toInt().coerceIn(0, max(0, sh - h))

        val rel = pts.map { PointF(it.x - baseX, it.y - baseY) }
        var startX = 0
        var startY = 0
        val view = PinnedView(
            this, rel,
            onPress = {
                startX = lp.x
                startY = lp.y
            },
            onDrag = { dx, dy ->
                lp.x = (startX + dx).toInt().coerceIn(0, max(0, sw - w))
                lp.y = (startY + dy).toInt().coerceIn(0, max(0, sh - h))
                val av = armedView
                if (av != null) {
                    try {
                        wm.updateViewLayout(av, lp)
                    } catch (_: Exception) {
                    }
                }
            },
            onRelease = { moved ->
                val tx = (lp.x - baseX).toFloat()
                val ty = (lp.y - baseY).toFloat()
                Store.setPin(this, g.id, tx, ty)
                if (multi) {
                    // الكور الكتيرة بتختفي وتفضل كورة واحدة ثابتة في المكان اللي حطّيتها فيه
                    handler.post { showBalls(g, tx, ty, false) }
                } else if (!moved && Store.tapCircles(this)) {
                    fireArmed()
                }
            }
        )
        try {
            wm.addView(view, lp)
        } catch (_: Exception) {
            return
        }
        armedGesture = g
        armedView = view
        armedLp = lp
        armedBaseX = baseX
        armedBaseY = baseY
        if (multi) toast("حرّك الكور للمكان المطلوب. ضغطة مطوّلة أو ضغطتين على الزر = تنفيذ، وضغطة واحدة = إخفاء")
    }

    private fun setArmedTouchable(touchable: Boolean) {
        val v = armedView ?: return
        val lp = armedLp ?: return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    private fun fireArmed() {
        val g = armedGesture ?: return
        val lp = armedLp ?: return
        val offX = (lp.x - armedBaseX).toFloat()
        val offY = (lp.y - armedBaseY).toFloat()
        // نخلي الدواير "شفافة للمس" وقت التنفيذ عشان اللمسة توصل للتطبيق اللي تحتها
        setArmedTouchable(false)
        runGesture(g, offX, offY, true) { setArmedTouchable(true) }
    }

    private fun closeArmed() {
        armedView?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        armedView = null
        armedLp = null
        armedGesture = null
    }

    private fun runGesture(g: Gesture, offX: Float, offY: Float, keepScale: Boolean = false, end: (() -> Unit)? = null) {
        stopPlaying()
        val (sw, sh) = screenSize()
        if (!keepScale && (g.screenW > g.screenH) != (sw > sh)) {
            toast("اتجاه الشاشة مختلف عن وقت التسجيل (طولي / عرضي)")
            end?.invoke()
            return
        }
        val sx = if (keepScale) 1f else sw.toFloat() / g.screenW
        val sy = if (keepScale) 1f else sh.toFloat() / g.screenH
        val chain = buildChain(g, sw, sh, sx, sy, offX, offY)
        val chunks = if (chain == null) buildChunks(g, sw, sh, sx, sy, offX, offY) else emptyList()
        if (chain == null && chunks.isEmpty()) {
            end?.invoke()
            return
        }
        onEnd = end

        val token = ++runToken
        playing = true
        var count = 0

        fun again() {
            if (token != runToken) return
            val finished: () -> Unit = {
                count++
                if (g.repeat > 0 && count >= g.repeat) {
                    stopPlaying()
                } else {
                    handler.postDelayed({ again() }, g.repeatDelay)
                }
            }
            if (chain != null) runChain(chain, 0, null, token, finished)
            else runChunks(chunks, 0, 0L, token, finished)
        }
        again()
    }

    /**
     * إصبع واحد فيه "وقفة" (مثلاً: اضغط واستنى ثم اسحب): نقسمها لمراحل ونكمّلها كإصبع واحد نازل طول الوقت،
     * عشان التوقيت يطلع زي التسجيل بالظبط. غير كده بنرجع null ونستخدم الطريقة العادية.
     */
    private fun buildChain(g: Gesture, sw: Int, sh: Int, sx: Float, sy: Float, offX: Float, offY: Float): List<Seg>? {
        if (g.strokes.size != 1) return null
        val s = g.strokes[0]
        val n = s.points.size
        if (n < 3) return null
        val speed = if (g.speed < 0.1f) 1f else g.speed
        val xs = FloatArray(n) { (s.points[it].x * sx + offX).coerceIn(0f, sw - 1f) }
        val ys = FloatArray(n) { (s.points[it].y * sy + offY).coerceIn(0f, sh - 1f) }
        val ts = LongArray(n) { s.points[it].t }
        val maxDur = GestureDescription.getMaxGestureDuration()

        val segs = ArrayList<Seg>()
        var cur = Path()
        cur.moveTo(xs[0], ys[0])
        var curStart = ts[0]
        var hasHold = false

        for (k in 0 until n - 1) {
            val dt = ts[k + 1] - ts[k]
            if (dt >= 150L) {
                hasHold = true
                if (ts[k] - curStart > 0L) {
                    cur.lineTo(xs[k], ys[k])
                    segs.add(Seg(cur, max(1L, ((ts[k] - curStart) / speed).toLong())))
                }
                val hold = Path()
                hold.moveTo(xs[k], ys[k])
                segs.add(Seg(hold, max(1L, (dt / speed).toLong())))
                cur = Path()
                cur.moveTo(xs[k], ys[k])
                cur.lineTo(xs[k + 1], ys[k + 1])
                curStart = ts[k + 1]
            } else {
                cur.lineTo(xs[k + 1], ys[k + 1])
            }
        }
        val tail = ts[n - 1] - curStart
        if (tail > 0L) segs.add(Seg(cur, max(1L, (tail / speed).toLong())))

        if (!hasHold || segs.size < 2) return null
        return segs.map { Seg(it.path, min(it.dur, maxDur)) }
    }

    private fun runChain(segs: List<Seg>, idx: Int, prev: GestureDescription.StrokeDescription?, token: Int, done: () -> Unit) {
        if (token != runToken) return
        val seg = segs[idx]
        val last = idx == segs.size - 1
        val sd = if (prev == null) {
            GestureDescription.StrokeDescription(seg.path, 0L, seg.dur, !last)
        } else {
            prev.continueStroke(seg.path, 0L, seg.dur, !last)
        }
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(sd).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (last) done() else runChain(segs, idx + 1, sd, token, done)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (token == runToken) stopPlaying()
                }
            },
            null
        )
        if (!ok) stopPlaying()
    }

    private fun buildChunks(g: Gesture, sw: Int, sh: Int, sx: Float, sy: Float, offX: Float, offY: Float): List<Chunk> {
        val speed = if (g.speed < 0.1f) 1f else g.speed
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        val maxDur = GestureDescription.getMaxGestureDuration()

        val specs = ArrayList<Spec>()
        for (s in g.strokes.sortedBy { it.startOffset }) {
            val n = s.points.size
            if (n == 0) continue
            val xs = FloatArray(n)
            val ys = FloatArray(n)
            var travel = 0f
            for (i in 0 until n) {
                xs[i] = (s.points[i].x * sx + offX).coerceIn(0f, sw - 1f)
                ys[i] = (s.points[i].y * sy + offY).coerceIn(0f, sh - 1f)
                if (i > 0) travel += abs(xs[i] - xs[i - 1]) + abs(ys[i] - ys[i - 1])
            }
            val path = Path()
            path.moveTo(xs[0], ys[0])
            if (travel >= 2f) {
                for (i in 1 until n) path.lineTo(xs[i], ys[i])
            }
            val dur = min(max(1L, (s.duration / speed).toLong()), maxDur)
            specs.add(Spec(if (g.simultaneous) 0L else (s.startOffset / speed).toLong(), dur, path))
        }

        val chunks = ArrayList<Chunk>()
        var i = 0
        while (i < specs.size) {
            val part = ArrayList(specs.subList(i, min(i + maxStrokes, specs.size)))
            chunks.add(Chunk(part, part.minOf { it.start }, part.maxOf { it.start + it.dur }))
            i += maxStrokes
        }
        return chunks
    }

    private fun runChunks(chunks: List<Chunk>, idx: Int, prevEnd: Long, token: Int, done: () -> Unit) {
        if (token != runToken) return
        if (idx >= chunks.size) {
            done()
            return
        }
        val c = chunks[idx]
        val wait = if (idx == 0) 0L else max(0L, c.minStart - prevEnd)
        handler.postDelayed({
            if (token != runToken) return@postDelayed
            val b = GestureDescription.Builder()
            for (s in c.specs) {
                b.addStroke(GestureDescription.StrokeDescription(s.path, s.start - c.minStart, s.dur))
            }
            val ok = dispatchGesture(
                b.build(),
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        runChunks(chunks, idx + 1, c.endTime, token, done)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (token == runToken) stopPlaying()
                    }
                },
                null
            )
            if (!ok) stopPlaying()
        }, wait)
    }
}
